﻿Public MustInherit Class objBase

    Private _verb As eVerb
    Public Property Verb As eVerb
        Get
            Return _verb
        End Get
        Set(value As eVerb)
            _verb = value
        End Set
    End Property

    Private _msgType As String
    Public Property msgType As String
        Get
            Return _msgType
        End Get
        Set(value As String)
            _msgType = value
        End Set
    End Property

    Private _source As String
    Public Property Source As String
        Get
            Return _source
        End Get
        Set(value As String)
            _source = value
        End Set
    End Property

    Private _TimeStamp As String
    Public Property TimeStamp As String
        Get
            Return _TimeStamp
        End Get
        Set(value As String)
            _TimeStamp = _TimeStamp
        End Set
    End Property

End Class
