﻿Imports System.Xml
Imports PriPROC6.MessageInterface

Public Class oMsgDiscovery : Inherits objBase

#Region "Constructors"

    '    Private _lm As IEnumerable(Of Lazy(Of svcDef, svcDefprops))
    '    Public Sub New(LoadedModules As IEnumerable(Of Lazy(Of svcDef, svcDefprops)))
    '        _lm = LoadedModules
    '    End Sub

    '    Public Sub New()

    '    End Sub

#End Region

    '    Public ReadOnly Property Modules As IEnumerable(Of Lazy(Of svcDef, svcDefprops))
    '        Get
    '            Return _lm
    '        End Get
    '    End Property

End Class
